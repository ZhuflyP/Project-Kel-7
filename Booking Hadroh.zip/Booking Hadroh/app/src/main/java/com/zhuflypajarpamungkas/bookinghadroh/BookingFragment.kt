package com.zhuflypajarpamungkas.bookinghadroh

import android.app.DatePickerDialog
import android.os.Bundle
import android.text.TextUtils
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import java.util.*

class BookingFragment : Fragment() {

    private var selectedDate: Calendar = Calendar.getInstance()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_booking, container, false)

        val dateTextView = view.findViewById<TextView>(R.id.dateTextView)
        val pickDateButton = view.findViewById<Button>(R.id.pickDateButton)
        val locationEditText = view.findViewById<EditText>(R.id.locationEditText)
        val notesEditText = view.findViewById<EditText>(R.id.notesEditText)
        val bookButton = view.findViewById<Button>(R.id.bookButton)
        val bookingStatusTextView = view.findViewById<TextView>(R.id.bookingStatusTextView)

        // Initial date display
        updateDateText(dateTextView)

        pickDateButton.setOnClickListener {
            showDatePicker(dateTextView)
        }

        bookButton.setOnClickListener {
            val location = locationEditText.text.toString()
            if (TextUtils.isEmpty(location)) {
                bookingStatusTextView.text = "Please enter a location."
                bookingStatusTextView.setTextColor(resources.getColor(android.R.color.holo_red_dark))
                return@setOnClickListener
            }
            // For demo, just confirm booking with a message
            val bookingInfo = "Booked Hadroh on ${dateTextView.text} at $location"
            bookingStatusTextView.text = bookingInfo
            bookingStatusTextView.setTextColor(resources.getColor(android.R.color.holo_green_dark))
        }

        return view
    }

    private fun showDatePicker(dateTextView: TextView) {
        val year = selectedDate.get(Calendar.YEAR)
        val month = selectedDate.get(Calendar.MONTH)
        val day = selectedDate.get(Calendar.DAY_OF_MONTH)

        val datePickerDialog = DatePickerDialog(requireContext(), { _, y, m, d ->
            selectedDate.set(Calendar.YEAR, y)
            selectedDate.set(Calendar.MONTH, m)
            selectedDate.set(Calendar.DAY_OF_MONTH, d)
            updateDateText(dateTextView)
        }, year, month, day)
        datePickerDialog.show()
    }

    private fun updateDateText(dateTextView: TextView) {
        val year = selectedDate.get(Calendar.YEAR)
        val month = selectedDate.get(Calendar.MONTH) + 1 // Month is zero-based
        val day = selectedDate.get(Calendar.DAY_OF_MONTH)
        dateTextView.text = "$day/$month/$year"
    }
}
