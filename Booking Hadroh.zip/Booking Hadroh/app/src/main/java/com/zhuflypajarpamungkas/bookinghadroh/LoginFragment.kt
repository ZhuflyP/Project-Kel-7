package com.zhuflypajarpamungkas.bookinghadroh

import android.os.Bundle
import android.text.TextUtils
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.navigation.fragment.findNavController

class LoginFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view = inflater.inflate(R.layout.fragment_login, container, false)

        val usernameEditText = view.findViewById<EditText>(R.id.usernameEditText)
        val passwordEditText = view.findViewById<EditText>(R.id.passwordEditText)
        val loginButton = view.findViewById<Button>(R.id.loginButton)
        val loginStatusTextView = view.findViewById<TextView>(R.id.loginStatusTextView)

        loginButton.setOnClickListener {
            val username = usernameEditText.text.toString()
            val password = passwordEditText.text.toString()
            if (TextUtils.isEmpty(username) || TextUtils.isEmpty(password)) {
                loginStatusTextView.text = "Username and Password must be filled"
                loginStatusTextView.setTextColor(resources.getColor(android.R.color.holo_red_dark))
            } else {
                // For demo, accept any non-empty username and password
                loginStatusTextView.text = "Login success"
                loginStatusTextView.setTextColor(resources.getColor(android.R.color.holo_green_dark))
                // Navigate to booking fragment
                findNavController().navigate(R.id.action_loginFragment_to_bookingFragment)
            }
        }

        return view
    }

}
